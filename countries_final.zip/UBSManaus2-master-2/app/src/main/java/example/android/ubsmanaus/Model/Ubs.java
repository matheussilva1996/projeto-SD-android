package example.android.ubsmanaus.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Ubs<latlng> implements Serializable {

    public long id;

    @SerializedName("name")
    public String name;

    @SerializedName("alpha2Code")
    public String alpha2Code;

    @SerializedName("capital")
    public String capital;

    @SerializedName("region")
    public String region;

    @SerializedName("subregion")
    public String subregion;

    @SerializedName("population")
    public String population;

    @SerializedName("area")
    public String area;


    @SerializedName("numericCode")
    public String numericCode;

    @SerializedName("relevance")
    public String relevance;


    public Ubs(String name, String alpha2Code, String capital, String region, String subregion,
               String population, String area, String numericCode, String relevance) {

        this.name = name;
        this.alpha2Code = alpha2Code;
        this.capital = capital;
        this.region = region;
        this.subregion = subregion;
        this.population = population;
        this.area = area;
        this.numericCode = numericCode;
        this.relevance = relevance;
    }

    @Override
    public String toString() {
        return "Con{" +
                " name='" + name + '\'' +
                " capital='" + capital + '\'' +
                '}';
    }


    public String getName() {
        return name;
    }

    public String getAlpha2Code() {
        return alpha2Code;
    }

    public String getCapital() {
        return capital;
    }

    public String getRegion() {
        return region;
    }

    public String getSubregion() {
        return subregion;
    }

    public String getPopulation() {
        return population;
    }

    public String getArea() {
        return area;
    }

    public String getNumericCode() {
        return numericCode;
    }

    public String getRelevance() {
        return relevance;
    }


}
